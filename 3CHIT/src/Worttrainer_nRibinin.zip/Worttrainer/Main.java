package Worttrainer;

/**
 * Alle Methoden der anderen 3 Klassen werden getestet
 * @author Nathaniel Ribinin
 * @version 19-09-2022
 */
public class Main {
    public static void main(String[] args) {
        WortEintrag w1 = new WortEintrag("Esel", "https://www.ribinin.at");
        if (WortEintrag.checkUrl("https://www.ribinin.at") == true) {
            System.out.println("Diese URL ist gültig!");
        } else {
            System.out.println("Diese URL ist nicht gültig!");
        }
        System.out.println(w1.toString());
        WortEintrag w2 = new WortEintrag("Hund", "https://www.muehlboeck.com");
        if (WortEintrag.checkUrl("https://www.muehlboeck.com") == true) {
            System.out.println("Diese URL ist gültig!");
        } else {
            System.out.println("Diese URL ist nicht gültig!");
        }
        System.out.println(w1.toString());
        WortEintrag w3 = new WortEintrag("Hase", "https://www.list.com");
        if (WortEintrag.checkUrl("https://www.list.com") == true) {
            System.out.println("Diese URL ist gültig!");
        } else {
            System.out.println("Diese URL ist nicht gültig!");
        }
        //----
        System.out.println();
        System.out.println(w1.toString());
        System.out.println();
        WortListe woerter = new WortListe();
        woerter.addWort(w1);
        woerter.addWort(w2);
        woerter.addWort(w3);
        System.out.println(woerter.toString());
        System.out.println();
        System.out.println(woerter.indexEingabe(0).toString());
        System.out.println();
        woerter.deleteWort("Esel");
        System.out.println(woerter.toString());
        WortTrainer n1 = new WortTrainer(woerter);
        System.out.println(n1.randomGenerator().toString());
        System.out.println();
        System.out.println(n1.check("Hund"));
        System.out.println(n1.checkIgnore("hUND"));
    }
}
