package Worttrainer;
import java.util.Random;

/**
 * Es wird aus dem Array eine Zahl gezogen und gleicht Wörter mit anderen
 * @author Nathaniel Ribinin
 * @version 19-09-2022
 */
public class WortTrainer {
    private WortListe list;
    private WortEintrag eintrag;

    public WortTrainer(WortListe list){
        this.list = list;
    }

    /**
     * Es soll von den Index eine zufällige Zahl rausgesucht werden und
     * das Wort des Indexes zurückgegeben
     * @return das Wort des Indexes
     */
    public WortEintrag randomGenerator(){
        int generator = (int)(Math.random() * list.getLaenge());
        this.eintrag = list.indexEingabe(generator);
        return list.indexEingabe(generator);
    }

    /**
     * Das Wort von Randomgenerator soll mit einem ausgewählten Wort geprüft werden und gibt
     * true bei Erfolg und false bei keinem Erfolg zurück
     * @param wort wird als Parameter übernommen
     * @return ob die Prüfung ein Erfolg war oder nicht
     */
    public boolean check(String wort){
        if(this.eintrag.getWort().equals(wort)){
            return true;
        }
        return false;
    }

    /**
     * Funktioniert gleich wie die Methode check, nur dass auf Groß- und
     * Kleinschreibung nicht geachtet wird
     * @param wort wird als Parameter übernommen
     * @return ob die Prüfung ein Erfolg war oder nicht
     */
    public boolean checkIgnore(String wort){
        if(this.eintrag.getWort().equalsIgnoreCase(wort)){
            return true;
        }
        return false;
    }
}
